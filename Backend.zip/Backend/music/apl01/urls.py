from django.urls import path
from apl01 import views 
from apl01.views import temp,Signup
from apl01.views import sri,Signup
from apl01.views import sri,Login
from apl01.views import sri,Categories
from apl01.views import sri,Vendor
from apl01.views import sri,Premium
from apl01.views import sri,logout





urlpatterns = [
    path('',views.temp,name='temp'),
    path('signup',Signup.as_view(),name='signup'),
    path('login',Login.as_view(),name='login'),
    path('categories',Categories.as_view(),name='categories'),
    path('premium',Premium.as_view(),name='premium'),
    path('sri',views.sri,name='sri'),
    path('vendor',Vendor.as_view(),name='vendor'),
    path('logout', logout, name='logout'),
]
