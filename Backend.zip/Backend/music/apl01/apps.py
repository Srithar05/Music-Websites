from django.apps import AppConfig


class Apl01Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apl01'
